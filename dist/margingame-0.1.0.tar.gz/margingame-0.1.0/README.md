`pip install margingame`

This package is mainly for just one class, `Initialise(...)`. 
You can:
<ul>
<li> Pass in non-default parameters for a custom game. </li>
<li> Get attributes, notably payoff matrices as Pandas dataframes. </li>
<li> Use the method to calculate the Nash equilibria. </li>
</ul>

See the code, notably Initialise.py, for more info.
